def classFactory(iface):
    from .plugin import SubstationProximityPlugin
    return SubstationProximityPlugin(iface)
