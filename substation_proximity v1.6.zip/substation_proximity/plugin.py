"""
Substation Proximity Plugin for QGIS
"""

import os
import json
from urllib.request import urlopen, Request
from urllib.parse import quote

from qgis.core import (
    Qgis,
    QgsProject,
    QgsGeometry,
    QgsPointXY,
    QgsRectangle,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsTextAnnotation,
    QgsFillSymbol,
)
from qgis.gui import (
    QgsMapToolEmitPoint,
    QgsRubberBand,
    QgsVertexMarker,
)
from qgis.PyQt.QtCore import Qt, QPointF, QPoint
from qgis.PyQt.QtGui import QColor, QFont, QTextDocument, QIcon
from qgis.PyQt.QtWidgets import (
    QAction, QApplication, QComboBox, QToolButton,
    QFrame, QFormLayout, QLabel, QDoubleSpinBox, QCheckBox, QHBoxLayout,
)


# ---------------------------------------------------------------------------
# CONFIG
# ---------------------------------------------------------------------------
RADIUS_OPTIONS = {
    "2.5 km": 2500,
    "5 km":   5000,
    "7.5 km": 7500,
}
DEFAULT_RADIUS = "5 km"


DEFAULT_COST_MV_PER_KM   = 10.1
DEFAULT_COST_HV_PER_KM   = 16.2
DEFAULT_DEVIATION_FACTOR  = 1.3

# Pixel radius within which a label is considered hovered
HOVER_HIT_PX = 60

LINE_COLOR        = QColor(220, 40, 40, 200)
LINE_WIDTH        = 2
HOVER_LINE_WIDTH  = 3
HIGHLIGHT_COLOR = QColor(255, 255, 0, 180)
HIGHLIGHT_SIZE  = 14

OVERPASS_ENDPOINTS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
    "https://overpass.openstreetmap.ru/api/interpreter",
]


# ---------------------------------------------------------------------------
# VOLTAGE HELPERS
# ---------------------------------------------------------------------------
def parse_voltages(voltage_str):
    if not voltage_str:
        return []
    result = []
    for part in voltage_str.split(";"):
        part = part.strip()
        try:
            result.append(int(float(part)))
        except (ValueError, TypeError):
            pass
    return result


def voltage_matches(voltage_str, voltage_filter):
    """Return True if this substation passes the voltage filter.

    voltage_filter is either:
      None                              → show all
      {'voltages': set, 'include_other': bool}
    """
    if voltage_filter is None:
        return True
    parsed = set(parse_voltages(voltage_str))
    known  = {110000, 220000, 380000}
    # Match any of the explicitly checked voltages
    if parsed & voltage_filter['voltages']:
        return True
    # "Other": no voltage tag, or voltage not in the three known levels
    if voltage_filter['include_other']:
        if not parsed:
            return True                      # no voltage tag at all
        if not (parsed & known):
            return True                      # has voltage but none of the three
    return False


def format_voltage(voltage_str):
    volts = parse_voltages(voltage_str)
    if not volts:
        return ""
    return "/".join(str(v // 1000) for v in volts) + " kV"


# ---------------------------------------------------------------------------
# COST HELPERS
# ---------------------------------------------------------------------------
def compute_costs(dist_m, cost_mv, cost_hv, deviation):
    dist_km = dist_m / 1000.0
    return dist_km * cost_mv * deviation, dist_km * cost_hv * deviation


def fmt_meur(value):
    if value >= 100:
        return f"~{value:.0f} M€"
    return f"~{value:.1f} M€"


# ---------------------------------------------------------------------------
# ANNOTATION BUILDER
# ---------------------------------------------------------------------------
def build_annotation(map_point, crs, label_html, highlighted=False):
    """Create and return (QgsTextAnnotation, doc_size) positioned at map_point."""
    bg = "rgba(255,255,180,0.97)" if highlighted else "rgba(255,255,255,0.85)"
    border = "1px solid #b06000;" if highlighted else "none;"

    annotation = QgsTextAnnotation()
    doc = QTextDocument()
    doc.setDefaultFont(QFont("Arial", 9, QFont.Bold))
    doc.setHtml(
        f'<div style="background: {bg}; border: {border} '
        f'padding: 3px 6px; font-size: 9pt; font-weight: bold; '
        f'color: #333;">{label_html}</div>'
    )
    annotation.setDocument(doc)
    doc_size = doc.size()
    annotation.setFrameSize(doc_size)
    annotation.setMapPosition(map_point)
    annotation.setMapPositionCrs(crs)
    annotation.setHasFixedMapPosition(True)
    annotation.setFrameOffsetFromReferencePoint(QPointF(10, -10))
    symbol = QgsFillSymbol.createSimple(
        {"color": "255,255,255,0", "style": "no", "outline_style": "no"}
    )
    annotation.setFillSymbol(symbol)
    return annotation, doc_size


# ---------------------------------------------------------------------------
# SETTINGS POPUP
# ---------------------------------------------------------------------------
class SettingsPopup(QFrame):

    def __init__(self, parent):
        super().__init__(parent, Qt.Popup)
        self.setFrameShape(QFrame.StyledPanel)
        self.setFrameShadow(QFrame.Raised)
        self.setStyleSheet("""
            QFrame {
                background: palette(window);
                border: 1px solid palette(mid);
                border-radius: 4px;
            }
            QLabel#section {
                font-size: 8pt;
                color: palette(mid);
                font-weight: bold;
            }
            QLabel { font-size: 9pt; }
            QComboBox      { font-size: 9pt; min-width: 145px; }
            QDoubleSpinBox { font-size: 9pt; min-width: 100px; }
        """)

        layout = QFormLayout(self)
        layout.setContentsMargins(10, 8, 10, 10)
        layout.setSpacing(5)
        layout.setLabelAlignment(Qt.AlignRight | Qt.AlignVCenter)

        # ── Search ────────────────────────────────────────────────────
        lbl_search = QLabel("SEARCH")
        lbl_search.setObjectName("section")
        layout.addRow(lbl_search)

        self.radius_combo = QComboBox()
        self.radius_combo.addItems(RADIUS_OPTIONS.keys())
        self.radius_combo.setCurrentText(DEFAULT_RADIUS)
        layout.addRow(QLabel("Radius:"), self.radius_combo)

        # Voltage checkboxes — one per level, all checked by default
        self.cb_110   = QCheckBox("110 kV")
        self.cb_220   = QCheckBox("220 kV")
        self.cb_380   = QCheckBox("380 kV")
        self.cb_other = QCheckBox("Other")
        for cb in (self.cb_110, self.cb_220, self.cb_380, self.cb_other):
            cb.setChecked(True)
            cb.setStyleSheet("QCheckBox { font-size: 9pt; }")
        cb_row = QHBoxLayout()
        cb_row.setSpacing(10)
        cb_row.setContentsMargins(0, 0, 0, 0)
        cb_row.addWidget(self.cb_110)
        cb_row.addWidget(self.cb_220)
        cb_row.addWidget(self.cb_380)
        cb_row.addWidget(self.cb_other)
        layout.addRow(QLabel("Voltage:"), cb_row)

        sep1 = QFrame()
        sep1.setFrameShape(QFrame.HLine)
        sep1.setFrameShadow(QFrame.Sunken)
        layout.addRow(sep1)

        # ── Connection cost rates ─────────────────────────────────────
        lbl_cost = QLabel("CONNECTION COST RATES")
        lbl_cost.setObjectName("section")
        layout.addRow(lbl_cost)

        self.cost_mv_spin = QDoubleSpinBox()
        self.cost_mv_spin.setRange(0.1, 999.9)
        self.cost_mv_spin.setDecimals(1)
        self.cost_mv_spin.setSingleStep(0.1)
        self.cost_mv_spin.setSuffix(" M€/km")
        self.cost_mv_spin.setValue(DEFAULT_COST_MV_PER_KM)
        layout.addRow(QLabel("20 kV:"), self.cost_mv_spin)

        self.cost_hv_spin = QDoubleSpinBox()
        self.cost_hv_spin.setRange(0.1, 999.9)
        self.cost_hv_spin.setDecimals(1)
        self.cost_hv_spin.setSingleStep(0.1)
        self.cost_hv_spin.setSuffix(" M€/km")
        self.cost_hv_spin.setValue(DEFAULT_COST_HV_PER_KM)
        layout.addRow(QLabel("110 kV:"), self.cost_hv_spin)

        sep2 = QFrame()
        sep2.setFrameShape(QFrame.HLine)
        sep2.setFrameShadow(QFrame.Sunken)
        layout.addRow(sep2)

        # ── Routing ───────────────────────────────────────────────────
        lbl_dev = QLabel("ROUTING")
        lbl_dev.setObjectName("section")
        layout.addRow(lbl_dev)

        self.deviation_spin = QDoubleSpinBox()
        self.deviation_spin.setRange(1.0, 5.0)
        self.deviation_spin.setDecimals(2)
        self.deviation_spin.setSingleStep(0.05)
        self.deviation_spin.setValue(DEFAULT_DEVIATION_FACTOR)
        self.deviation_spin.setToolTip(
            "Multiplier on straight-line distance to account for\n"
            "real-world cable routing (1.30 = +30% deviation)"
        )
        layout.addRow(QLabel("Deviation:"), self.deviation_spin)

        self.adjustSize()

    def show_near(self, gear_button):
        pos = gear_button.mapToGlobal(QPoint(0, gear_button.height() + 2))
        self.move(pos)
        self.show()
        self.raise_()


# ---------------------------------------------------------------------------
# OVERPASS FETCH
# ---------------------------------------------------------------------------
def fetch_substations_for_extent(extent_proj):
    project_crs = QgsProject.instance().crs()
    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
    to_wgs = QgsCoordinateTransform(project_crs, wgs84, QgsProject.instance())

    extent_wgs = to_wgs.transformBoundingBox(extent_proj)
    bbox = (
        f"{extent_wgs.yMinimum()},{extent_wgs.xMinimum()},"
        f"{extent_wgs.yMaximum()},{extent_wgs.xMaximum()}"
    )

    query = f"""
    [out:json][timeout:60];
    (
      node["power"="substation"]({bbox});
      way["power"="substation"]({bbox});
      relation["power"="substation"]({bbox});
    );
    out body;
    >;
    out skel qt;
    """

    last_error = None
    for endpoint in OVERPASS_ENDPOINTS:
        try:
            req = Request(
                endpoint,
                data=f"data={quote(query)}".encode("utf-8"),
                method="POST",
            )
            response = urlopen(req, timeout=30)
            data = json.loads(response.read().decode("utf-8"))
            print(f"  Substation Proximity: OK from {endpoint.split('/')[2]}")
            return data
        except Exception as e:
            last_error = e
            print(f"  Substation Proximity: Failed {endpoint.split('/')[2]}: {e}")
            continue

    raise last_error


def parse_substations(overpass_data):
    project_crs = QgsProject.instance().crs()
    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
    xform = QgsCoordinateTransform(wgs84, project_crs, QgsProject.instance())

    nodes = {}
    for el in overpass_data["elements"]:
        if el["type"] == "node":
            nodes[el["id"]] = (el["lon"], el["lat"])

    substations = []
    for el in overpass_data["elements"]:
        tags = el.get("tags", {})
        if tags.get("power") != "substation":
            continue

        osm_id  = el["id"]
        name    = tags.get("name", "")
        voltage = tags.get("voltage", "")
        point_wgs = None

        if el["type"] == "node":
            point_wgs = QgsPointXY(el["lon"], el["lat"])
        elif el["type"] == "way" and "nodes" in el:
            coords = [nodes[n] for n in el["nodes"] if n in nodes]
            if len(coords) >= 2:
                avg_lon = sum(c[0] for c in coords) / len(coords)
                avg_lat = sum(c[1] for c in coords) / len(coords)
                point_wgs = QgsPointXY(avg_lon, avg_lat)

        if point_wgs:
            point_proj = xform.transform(point_wgs)
            substations.append((point_proj, name, voltage, osm_id))

    return substations


# ---------------------------------------------------------------------------
# CACHE
# ---------------------------------------------------------------------------
class SubstationCache:

    def __init__(self):
        self.substations = {}
        self.covered_extents = []

    def is_covered(self, point):
        for ext in self.covered_extents:
            if ext.contains(point):
                return True
        return False

    def add_results(self, substations, extent):
        for (point, name, voltage, osm_id) in substations:
            if osm_id not in self.substations:
                self.substations[osm_id] = (point, name, voltage)
        self.covered_extents.append(QgsRectangle(extent))

    def get_within_radius(self, click_point, radius):
        click_geom = QgsGeometry.fromPointXY(click_point)
        results = []
        for osm_id, (point, name, voltage) in self.substations.items():
            dist = click_geom.distance(QgsGeometry.fromPointXY(point))
            if dist <= radius:
                results.append((point, name, voltage, dist))
        return results

    def count(self):
        return len(self.substations)

    def clear(self):
        self.substations.clear()
        self.covered_extents.clear()


# ---------------------------------------------------------------------------
# MAP TOOL
# ---------------------------------------------------------------------------
class SubstationProximityTool(QgsMapToolEmitPoint):

    def __init__(self, canvas, cache, get_radius, get_voltage_filter, get_cost_settings):
        super().__init__(canvas)
        self.canvas             = canvas
        self.cache              = cache
        self.get_radius         = get_radius
        self.get_voltage_filter = get_voltage_filter
        self.get_cost_settings  = get_cost_settings
        self.rubber_bands       = []
        self.vertex_markers     = []
        self.annotations        = []   # one per result, white background, never touched after draw
        self.ann_label_boxes    = []   # list of (QgsPointXY midpoint, doc_w, doc_h) per annotation
        self.hover_annotation   = None # single extra annotation drawn on top when hovering
        self.click_marker       = None
        self.last_click_point   = None
        self.last_all_results   = None
        self.last_results       = None
        self.hovered_idx        = -1
        self.setCursor(Qt.CrossCursor)

        self.canvas.scaleChanged.connect(self.on_scale_changed)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _label_html(self, name, voltage, dist_m, cost_mv, cost_hv, deviation):
        dist_km = dist_m / 1000.0
        c_mv, c_hv = compute_costs(dist_m, cost_mv, cost_hv, deviation)
        voltage_lbl = format_voltage(voltage)

        lines = []
        if name and name.strip():
            lines.append(name.strip())
        if voltage_lbl:
            lines.append(voltage_lbl)
        lines.append(f"{dist_km:.2f} km")
        lines.append(
            f'<span style="color:#b06000;">{fmt_meur(c_mv)} / 20 kV</span>'
        )
        lines.append(
            f'<span style="color:#b06000;">{fmt_meur(c_hv)} / 110 kV</span>'
        )
        return "<br>".join(lines)

    def _midpoint(self, click_point, sub_point):
        return QgsPointXY(
            (click_point.x() + sub_point.x()) / 2,
            (click_point.y() + sub_point.y()) / 2,
        )

    # ------------------------------------------------------------------
    # Annotation management
    # ------------------------------------------------------------------
    def _clear_base_annotations(self):
        mgr = QgsProject.instance().annotationManager()
        for ann in self.annotations:
            mgr.removeAnnotation(ann)
        self.annotations.clear()
        self.ann_label_boxes.clear()

    def _clear_hover_annotation(self):
        if self.hover_annotation is not None:
            QgsProject.instance().annotationManager().removeAnnotation(
                self.hover_annotation
            )
            self.hover_annotation = None

    def _build_base_annotations(self):
        """Draw one plain-white annotation per result. Called once after a click."""
        if not self.last_click_point or not self.last_results:
            return
        crs = QgsProject.instance().crs()
        cost_mv, cost_hv, deviation = self.get_cost_settings()
        for sub_point, name, voltage, dist in self.last_results:
            mp   = self._midpoint(self.last_click_point, sub_point)
            html = self._label_html(name, voltage, dist, cost_mv, cost_hv, deviation)
            ann, doc_size = build_annotation(mp, crs, html, highlighted=False)
            QgsProject.instance().annotationManager().addAnnotation(ann)
            self.annotations.append(ann)
            self.ann_label_boxes.append((mp, doc_size.width(), doc_size.height()))

    def _set_hover(self, new_idx):
        """Swap hover annotation and highlight the associated line/marker."""
        if new_idx == self.hovered_idx:
            return

        # Restore previous hovered line/marker
        old_idx = self.hovered_idx
        if 0 <= old_idx < len(self.rubber_bands):
            self.rubber_bands[old_idx].setColor(LINE_COLOR)
            self.rubber_bands[old_idx].setWidth(LINE_WIDTH)
            self.rubber_bands[old_idx].setLineStyle(Qt.DashLine)
            self.rubber_bands[old_idx].update()
        if 0 <= old_idx < len(self.vertex_markers):
            self.vertex_markers[old_idx].setColor(HIGHLIGHT_COLOR)
            self.vertex_markers[old_idx].setFillColor(HIGHLIGHT_COLOR)
            self.vertex_markers[old_idx].update()

        self.hovered_idx = new_idx
        self._clear_hover_annotation()

        if new_idx < 0 or not self.last_results or new_idx >= len(self.last_results):
            return

        # Style new hovered line/marker
        if new_idx < len(self.rubber_bands):
            self.rubber_bands[new_idx].setColor(LINE_COLOR)
            self.rubber_bands[new_idx].setWidth(HOVER_LINE_WIDTH)
            self.rubber_bands[new_idx].setLineStyle(Qt.SolidLine)
            self.rubber_bands[new_idx].update()
        if new_idx < len(self.vertex_markers):
            self.vertex_markers[new_idx].setColor(LINE_COLOR)
            self.vertex_markers[new_idx].setFillColor(LINE_COLOR)
            self.vertex_markers[new_idx].update()

        sub_point, name, voltage, dist = self.last_results[new_idx]
        mp   = self._midpoint(self.last_click_point, sub_point)
        crs  = QgsProject.instance().crs()
        cost_mv, cost_hv, deviation = self.get_cost_settings()
        html = self._label_html(name, voltage, dist, cost_mv, cost_hv, deviation)
        ann, _doc_size = build_annotation(mp, crs, html, highlighted=True)
        QgsProject.instance().annotationManager().addAnnotation(ann)
        self.hover_annotation = ann
        self.canvas.update()

    # ------------------------------------------------------------------
    # Hover hit-test
    # ------------------------------------------------------------------
    def _find_hovered(self, cursor_pos):
        """Return the index of the label whose rendered bounding box contains cursor.

        Each label box top-left is at (anchor_screen.x + 10, anchor_screen.y - 10)
        and extends right/down by (doc_w, doc_h) — matching the annotation offset.
        Returns the last (topmost in draw order) hit, or -1 if none.
        """
        if not self.ann_label_boxes:
            return -1
        m2p = self.canvas.mapSettings().mapToPixel()
        cx, cy = cursor_pos.x(), cursor_pos.y()
        hit = -1
        for i, (mp, doc_w, doc_h) in enumerate(self.ann_label_boxes):
            px = m2p.transform(mp)
            # Annotation offset: +10px right, -10px up from anchor
            x0 = px.x() + 10
            y0 = px.y() - 10
            x1 = x0 + doc_w
            y1 = y0 + doc_h
            if x0 <= cx <= x1 and y0 <= cy <= y1:
                hit = i   # keep going — last match wins (topmost drawn)
        return hit

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------
    def canvasMoveEvent(self, event):
        if not self.ann_label_boxes:
            return
        self._set_hover(self._find_hovered(event.pos()))

    def on_scale_changed(self, _):
        if self.last_click_point and self.last_results is not None:
            saved_hover = self.hovered_idx
            self._clear_hover_annotation()
            self._clear_base_annotations()
            self._build_base_annotations()
            self.hovered_idx = -1
            self._set_hover(saved_hover)
            self._redraw_lines_and_markers()

    def apply_filter_and_redraw(self):
        if self.last_click_point is None or self.last_all_results is None:
            return
        filter_set = self.get_voltage_filter()
        self.last_results = [
            r for r in self.last_all_results
            if voltage_matches(r[2], filter_set)
        ]
        self.hovered_idx = -1
        self.clear_overlays()
        self.draw_results(self.last_click_point, self.last_results)

    def canvasReleaseEvent(self, event):
        click_point = self.toMapCoordinates(event.pos())
        self.clear_overlays()
        self.hovered_idx = -1

        radius = self.get_radius()

        if not self.cache.is_covered(click_point):
            print("Substation Proximity: New area — fetching from Overpass...")
            QApplication.setOverrideCursor(Qt.WaitCursor)
            try:
                extent = self.canvas.extent()
                extent.grow(radius)
                overpass_data = fetch_substations_for_extent(extent)
                substations = parse_substations(overpass_data)
                self.cache.add_results(substations, extent)
                print(
                    f"Substation Proximity: Cached {len(substations)} substations. "
                    f"Total: {self.cache.count()}"
                )
            except Exception as e:
                print(f"Substation Proximity: Fetch error: {e}")
                print("Substation Proximity: Try clicking again in a moment.")
                QApplication.restoreOverrideCursor()
                return
            finally:
                QApplication.restoreOverrideCursor()

        all_results = self.cache.get_within_radius(click_point, radius)
        self.last_click_point = click_point
        self.last_all_results = all_results

        filter_set = self.get_voltage_filter()
        filtered = [r for r in all_results if voltage_matches(r[2], filter_set)]
        self.last_results = filtered

        self.draw_results(click_point, filtered)

    # ------------------------------------------------------------------
    # Drawing
    # ------------------------------------------------------------------
    def draw_results(self, click_point, results):
        radius = self.get_radius()

        for sub_point, name, voltage, dist in results:
            # Line
            rb = QgsRubberBand(self.canvas, Qgis.GeometryType.Line)
            rb.setColor(LINE_COLOR)
            rb.setWidth(LINE_WIDTH)
            rb.setLineStyle(Qt.DashLine)
            rb.addPoint(click_point)
            rb.addPoint(sub_point)
            self.rubber_bands.append(rb)

            # Substation highlight
            vm = QgsVertexMarker(self.canvas)
            vm.setCenter(sub_point)
            vm.setColor(HIGHLIGHT_COLOR)
            vm.setFillColor(HIGHLIGHT_COLOR)
            vm.setIconSize(HIGHLIGHT_SIZE)
            vm.setIconType(QgsVertexMarker.ICON_CIRCLE)
            vm.setPenWidth(2)
            self.vertex_markers.append(vm)

        # Click marker on top
        self.click_marker = QgsVertexMarker(self.canvas)
        self.click_marker.setCenter(click_point)
        self.click_marker.setColor(QColor(0, 120, 255))
        self.click_marker.setFillColor(QColor(0, 120, 255, 150))
        self.click_marker.setIconSize(14)
        self.click_marker.setIconType(QgsVertexMarker.ICON_CIRCLE)
        self.click_marker.setPenWidth(3)
        self.click_marker.setZValue(100)

        # Base annotations — all labels drawn, hover brings one to top
        self._build_base_annotations()

        print(
            f"Substation Proximity: {len(results)} substations within "
            f"{radius/1000:.1f} km."
        )

    def _redraw_lines_and_markers(self):
        """Rebuild rubber-bands and vertex markers after a zoom change."""
        for rb in self.rubber_bands:
            self.canvas.scene().removeItem(rb)
        self.rubber_bands.clear()
        for vm in self.vertex_markers:
            self.canvas.scene().removeItem(vm)
        self.vertex_markers.clear()
        if self.click_marker:
            self.canvas.scene().removeItem(self.click_marker)
            self.click_marker = None

        if not self.last_click_point or not self.last_results:
            return

        for sub_point, name, voltage, dist in self.last_results:
            rb = QgsRubberBand(self.canvas, Qgis.GeometryType.Line)
            rb.setColor(LINE_COLOR)
            rb.setWidth(LINE_WIDTH)
            rb.setLineStyle(Qt.DashLine)
            rb.addPoint(self.last_click_point)
            rb.addPoint(sub_point)
            self.rubber_bands.append(rb)

            vm = QgsVertexMarker(self.canvas)
            vm.setCenter(sub_point)
            vm.setColor(HIGHLIGHT_COLOR)
            vm.setFillColor(HIGHLIGHT_COLOR)
            vm.setIconSize(HIGHLIGHT_SIZE)
            vm.setIconType(QgsVertexMarker.ICON_CIRCLE)
            vm.setPenWidth(2)
            self.vertex_markers.append(vm)

        self.click_marker = QgsVertexMarker(self.canvas)
        self.click_marker.setCenter(self.last_click_point)
        self.click_marker.setColor(QColor(0, 120, 255))
        self.click_marker.setFillColor(QColor(0, 120, 255, 150))
        self.click_marker.setIconSize(14)
        self.click_marker.setIconType(QgsVertexMarker.ICON_CIRCLE)
        self.click_marker.setPenWidth(3)
        self.click_marker.setZValue(100)

    def clear_overlays(self):
        self._clear_hover_annotation()
        self._clear_base_annotations()
        for rb in self.rubber_bands:
            self.canvas.scene().removeItem(rb)
        self.rubber_bands.clear()
        for vm in self.vertex_markers:
            self.canvas.scene().removeItem(vm)
        self.vertex_markers.clear()
        if self.click_marker:
            self.canvas.scene().removeItem(self.click_marker)
            self.click_marker = None
        self.hovered_idx = -1

    def deactivate(self):
        super().deactivate()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Delete:
            self.last_click_point = None
            self.last_all_results = None
            self.last_results     = None
            self.hovered_idx      = -1
            self.clear_overlays()
            print("Substation Proximity: Overlays cleared.")


# ---------------------------------------------------------------------------
# PLUGIN CLASS
# ---------------------------------------------------------------------------
class SubstationProximityPlugin:

    def __init__(self, iface):
        self.iface        = iface
        self.canvas       = iface.mapCanvas()
        self.action       = None
        self.gear_button  = None
        self.gear_action  = None
        self.popup        = None
        self.tool         = None
        self.cache        = None
        self.plugin_dir   = os.path.dirname(__file__)
        self.prefetched   = False

    def get_radius(self):
        if self.popup:
            return RADIUS_OPTIONS.get(self.popup.radius_combo.currentText(), 5000)
        return 5000

    def get_voltage_filter(self):
        """Return a filter dict or None (= show all).

        Returns None when all boxes are checked or all are unchecked.
        Otherwise returns a dict:
          {
            'voltages': set of int volt values to match,
            'include_other': bool  — also match unknown/unlisted voltages
          }
        """
        if not self.popup:
            return None
        v110   = self.popup.cb_110.isChecked()
        v220   = self.popup.cb_220.isChecked()
        v380   = self.popup.cb_380.isChecked()
        other  = self.popup.cb_other.isChecked()
        # All checked or all unchecked → no filter
        if (v110 and v220 and v380 and other) or not any([v110, v220, v380, other]):
            return None
        checked_v = set()
        if v110: checked_v.add(110000)
        if v220: checked_v.add(220000)
        if v380: checked_v.add(380000)
        return {'voltages': checked_v, 'include_other': other}

    def get_cost_settings(self):
        if self.popup:
            return (
                self.popup.cost_mv_spin.value(),
                self.popup.cost_hv_spin.value(),
                self.popup.deviation_spin.value(),
            )
        return DEFAULT_COST_MV_PER_KM, DEFAULT_COST_HV_PER_KM, DEFAULT_DEVIATION_FACTOR

    def _on_voltage_changed(self):
        if self.tool:
            self.tool.apply_filter_and_redraw()

    def _on_cost_changed(self):
        """Cost/deviation changed — rebuild all base labels and restore hover."""
        if self.tool and self.tool.last_results:
            saved = self.tool.hovered_idx
            self.tool._clear_hover_annotation()
            self.tool._clear_base_annotations()
            self.tool._build_base_annotations()
            self.tool.hovered_idx = -1
            self.tool._set_hover(saved)

    def toggle_popup(self):
        if self.popup.isVisible():
            self.popup.hide()
        else:
            self.popup.show_near(self.gear_button)

    def initGui(self):
        self.cache = SubstationCache()

        self.popup = SettingsPopup(self.iface.mainWindow())
        self.popup.cb_110.stateChanged.connect(self._on_voltage_changed)
        self.popup.cb_220.stateChanged.connect(self._on_voltage_changed)
        self.popup.cb_380.stateChanged.connect(self._on_voltage_changed)
        self.popup.cb_other.stateChanged.connect(self._on_voltage_changed)
        self.popup.cost_mv_spin.valueChanged.connect(self._on_cost_changed)
        self.popup.cost_hv_spin.valueChanged.connect(self._on_cost_changed)
        self.popup.deviation_spin.valueChanged.connect(self._on_cost_changed)

        self.tool = SubstationProximityTool(
            self.canvas, self.cache,
            self.get_radius, self.get_voltage_filter, self.get_cost_settings,
        )

        icon_path = os.path.join(self.plugin_dir, "icon.svg")
        self.action = QAction(
            QIcon(icon_path),
            "Substation Proximity",
            self.iface.mainWindow(),
        )
        self.action.setCheckable(True)
        self.action.setToolTip("Click map to find nearby substations")
        self.action.triggered.connect(self.on_action_triggered)

        # Gear button — small
        self.gear_button = QToolButton()
        self.gear_button.setText("⚙")
        self.gear_button.setToolTip("Substation Proximity settings")
        self.gear_button.setFixedSize(18, 18)
        self.gear_button.setStyleSheet(
            "QToolButton { font-size: 9pt; border: none; }"
            "QToolButton:hover  { background: palette(mid);  border-radius: 3px; }"
            "QToolButton:pressed{ background: palette(dark); border-radius: 3px; }"
        )
        self.gear_button.clicked.connect(self.toggle_popup)

        self.iface.addToolBarIcon(self.action)
        self.gear_action = self.iface.pluginToolBar().addWidget(self.gear_button)

        self.iface.addPluginToVectorMenu("Substation Proximity", self.action)
        self.canvas.mapToolSet.connect(self.on_tool_changed)

    def unload(self):
        if self.tool:
            try:
                self.canvas.scaleChanged.disconnect(self.tool.on_scale_changed)
            except TypeError:
                pass
            self.tool.last_click_point = None
            self.tool.last_all_results = None
            self.tool.last_results     = None
            self.tool.hovered_idx      = -1
            self.tool.clear_overlays()

        try:
            self.canvas.mapToolSet.disconnect(self.on_tool_changed)
        except TypeError:
            pass

        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginVectorMenu("Substation Proximity", self.action)

        if self.gear_action:
            self.iface.pluginToolBar().removeAction(self.gear_action)
        if self.gear_button:
            self.gear_button.deleteLater()

        if self.popup:
            for sig, slot in [
                (self.popup.cb_110.stateChanged,   self._on_voltage_changed),
                (self.popup.cb_220.stateChanged,   self._on_voltage_changed),
                (self.popup.cb_380.stateChanged,   self._on_voltage_changed),
                (self.popup.cb_other.stateChanged, self._on_voltage_changed),
                (self.popup.cost_mv_spin.valueChanged,        self._on_cost_changed),
                (self.popup.cost_hv_spin.valueChanged,        self._on_cost_changed),
                (self.popup.deviation_spin.valueChanged,      self._on_cost_changed),
            ]:
                try:
                    sig.disconnect(slot)
                except TypeError:
                    pass
            self.popup.close()
            self.popup.deleteLater()

        if self.cache:
            self.cache.clear()

        self.tool        = None
        self.cache       = None
        self.action      = None
        self.gear_button = None
        self.gear_action = None
        self.popup       = None

    def on_action_triggered(self, checked):
        if checked:
            self.canvas.setMapTool(self.tool)

            if not self.prefetched:
                self.prefetched = True
                QApplication.setOverrideCursor(Qt.WaitCursor)
                try:
                    print("Substation Proximity: Initial fetch for visible area...")
                    extent = self.canvas.extent()
                    extent.grow(self.get_radius())
                    overpass_data = fetch_substations_for_extent(extent)
                    substations = parse_substations(overpass_data)
                    self.cache.add_results(substations, extent)
                    print(
                        f"Substation Proximity: Cached {self.cache.count()} substations. Ready."
                    )
                except Exception as e:
                    print(f"Substation Proximity: Initial fetch failed: {e}")
                    print("Substation Proximity: Will try again on first click.")
                finally:
                    QApplication.restoreOverrideCursor()

    def on_tool_changed(self, new_tool):
        if self.action:
            self.action.setChecked(new_tool is self.tool)
